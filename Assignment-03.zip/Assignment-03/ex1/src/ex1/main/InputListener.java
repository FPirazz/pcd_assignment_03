package ex1.main;

public interface InputListener {

    void stopped();

    void started(final String d, final int i, final int ml, final int nTopFiles);
}

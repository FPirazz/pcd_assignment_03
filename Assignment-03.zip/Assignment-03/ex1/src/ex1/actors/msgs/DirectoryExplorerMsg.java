package ex1.actors.msgs;

public interface DirectoryExplorerMsg {
}

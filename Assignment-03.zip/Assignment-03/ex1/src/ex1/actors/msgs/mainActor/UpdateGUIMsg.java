package ex1.actors.msgs.mainActor;

import ex1.actors.msgs.MainActorMsg;

public class UpdateGUIMsg implements MainActorMsg {
}

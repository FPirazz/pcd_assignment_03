package ex1.actors.msgs.directoryExplorer;

import ex1.actors.msgs.DirectoryExplorerMsg;

public class DirectoryExplorerDoneMsg implements DirectoryExplorerMsg {
}

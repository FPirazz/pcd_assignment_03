package ex2.actorLogic.msgs.brushManager;

import ex2.actorLogic.msgs.ActorBrushManagerInterface;

public class RefreshViewMsg implements ActorBrushManagerInterface {
}

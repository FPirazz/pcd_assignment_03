package ex2.actorLogic.msgs.brushManager;

import ex2.actorLogic.msgs.ActorBrushManagerInterface;

public class BootMsg implements ActorBrushManagerInterface {
}

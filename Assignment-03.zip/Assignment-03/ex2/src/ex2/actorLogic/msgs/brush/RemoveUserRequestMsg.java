package ex2.actorLogic.msgs.brush;

import ex2.actorLogic.msgs.ActorBrushInterface;

public class RemoveUserRequestMsg implements ActorBrushInterface {
}

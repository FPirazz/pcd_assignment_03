package ex2.actorLogic.msgs.brush;

import ex2.actorLogic.msgs.ActorBrushInterface;

public class AddBrushRequestMsg implements ActorBrushInterface {
}

package ex2.actorLogic.msgs;

public interface ActorBrushInterface {
}

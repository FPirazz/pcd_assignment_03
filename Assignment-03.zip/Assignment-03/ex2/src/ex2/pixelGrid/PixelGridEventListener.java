package ex2.pixelGrid;

public interface PixelGridEventListener {
	void selectedCell(int x, int y);
}

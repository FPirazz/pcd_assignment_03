package ex2.pixelGrid;

public interface MouseMovedListener {
    void mouseMoved(int x, int y);
}

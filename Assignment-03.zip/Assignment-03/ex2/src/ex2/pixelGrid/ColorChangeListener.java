package ex2.pixelGrid;

public interface ColorChangeListener {
    void colorChanged(int color);
}
